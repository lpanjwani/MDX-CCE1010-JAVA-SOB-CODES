/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_42;

import javafx.geometry.Insets;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 *
 * @author Lavesh
 */
public class SOB_42 extends Application {

    @Override
    public void start(Stage primaryStage) {

        ToggleGroup group = new ToggleGroup();
        RadioButton Green = new RadioButton();
        Green.setText("Green");
        Green.setToggleGroup(group);

        RadioButton Yellow = new RadioButton();
        Yellow.setText("Yellow");
        Yellow.setToggleGroup(group);

        RadioButton Red = new RadioButton();
        Red.setText("Red");
        Red.setToggleGroup(group);
        Red.setSelected(true);

        Circle Circle_Red = new Circle(10);
        Circle_Red.setFill(Color.RED);

        Circle Circle_Yellow = new Circle(10);
        Circle_Yellow.setFill(Color.YELLOW);

        Circle Circle_Green = new Circle(10);
        Circle_Green.setFill(Color.GREEN);

        GridPane root = new GridPane();
        GridPane.setConstraints(Red, 0, 0);
        
        GridPane.setConstraints(Yellow, 0, 1);
        GridPane.setConstraints(Green, 0, 2);

        GridPane.setConstraints(Circle_Red, 1, 0);
        GridPane.setConstraints(Circle_Yellow, 1, 1);
        GridPane.setConstraints(Circle_Green, 1, 2);
        
        GridPane.setMargin(Circle_Red, new Insets(0, 0, 0, 50));
        GridPane.setMargin(Circle_Yellow, new Insets(0, 0, 0, 50));
        GridPane.setMargin(Circle_Green, new Insets(0, 0, 0, 50));
        
        root.getChildren().addAll(Green, Yellow, Red,Circle_Red);

        group.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
            @Override
            public void changed(ObservableValue<? extends Toggle> ov,
                    Toggle old_toggle, Toggle new_toggle) {
                if (group.getSelectedToggle().equals(Green)) {
                    root.getChildren().add(Circle_Green);
                    root.getChildren().remove(Circle_Yellow);
                    root.getChildren().remove(Circle_Red);
                } else if (group.getSelectedToggle().equals(Red)) {
                    root.getChildren().add(Circle_Red);
                    root.getChildren().remove(Circle_Yellow);
                    root.getChildren().remove(Circle_Green);
                } else if (group.getSelectedToggle().equals(Yellow)) {
                    root.getChildren().add(Circle_Yellow);
                    root.getChildren().remove(Circle_Red);
                    root.getChildren().remove(Circle_Green);
                }
            }
        });

        Scene scene = new Scene(root, 300, 250);

        primaryStage.setTitle("Traffic Lights!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
