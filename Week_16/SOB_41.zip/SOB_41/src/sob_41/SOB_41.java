/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_41;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 *
 * @author Lavesh
 */
public class SOB_41 extends Application {

    @Override
    public void start(Stage primaryStage) {

        TextField Decimal_Input = new TextField();
        TextField Hex_Input = new TextField();
        TextField Binary_Input = new TextField();

        Decimal_Input.setPromptText("Decimal Value");
        Hex_Input.setPromptText("HexaDecimal Value");
        Binary_Input.setPromptText("Binary Value");

        Decimal_Input.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode() == KeyCode.ENTER) {
                    try {
                        Hex_Input.setText(Integer.toHexString((Integer.parseInt((Decimal_Input.getText()), 10))));
                        Binary_Input.setText(Integer.toBinaryString((Integer.parseInt((Decimal_Input.getText()), 10))));
                    } catch (NumberFormatException ex) {
                        Alert alert = new Alert(AlertType.INFORMATION);
                        alert.setTitle("Invalid Input!");
                        alert.setContentText("Please Enter Valid Input!");
                        alert.show();
                    }
                }
            }
        });

        Hex_Input.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode() == KeyCode.ENTER) {
                    try {
                        Decimal_Input.setText(Integer.toString(Integer.parseInt(Hex_Input.getText(), 16)));
                        Binary_Input.setText(Integer.toBinaryString(Integer.parseInt(Hex_Input.getText(), 16)));
                    } catch (NumberFormatException ex) {
                        Alert alert = new Alert(AlertType.INFORMATION);
                        alert.setTitle("Invalid Input!");
                        alert.setContentText("Please Enter Valid Input!");
                        alert.show();
                    }
                }
            }
        });

        Binary_Input.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode() == KeyCode.ENTER) {
                    try {
                        Decimal_Input.setText(Integer.toString(Integer.parseInt(Binary_Input.getText(), 2)));
                        Hex_Input.setText(Integer.toHexString(Integer.parseInt(Binary_Input.getText(), 2)));
                    } catch (NumberFormatException ex) {
                        Alert alert = new Alert(AlertType.INFORMATION);
                        alert.setTitle("Invalid Input!");
                        alert.setContentText("Please Enter Valid Input!");
                        alert.show();
                    }
                }
            }

        });

        Label Decimal = new Label();
        Label Hex = new Label();
        Label Binary = new Label();

        Decimal.setText("Decimal: ");
        Hex.setText("Hexadecimal: ");
        Binary.setText("Binary: ");

        GridPane root = new GridPane();

        // Position of Elements/Nodes
        GridPane.setConstraints(Decimal, 0, 0);
        GridPane.setConstraints(Hex, 0, 1);
        GridPane.setConstraints(Binary, 0, 2);

        // Position of Elements/Nodes
        GridPane.setConstraints(Decimal_Input, 1, 0);
        GridPane.setConstraints(Hex_Input, 1, 1);
        GridPane.setConstraints(Binary_Input, 1, 2);

        root.getChildren().addAll(Decimal_Input, Hex_Input, Binary_Input, Decimal, Hex, Binary);

        Scene scene = new Scene(root, 300, 250);

        primaryStage.setTitle("Numerical Converter");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
