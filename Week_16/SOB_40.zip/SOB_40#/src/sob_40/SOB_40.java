package sob_40;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.TextField;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 *
 * @author M00692913
 */
public class SOB_40 extends Application {

    @Override
    public void start(Stage primaryStage) {

        // Celsuis Label
        Label Celsius_Text = new Label();
        Celsius_Text.setText("Celsius: ");

        // Fahrenheit Label
        Label Fahrenheit_Text = new Label();
        Fahrenheit_Text.setText("Fahrenheit: ");

        // Celsuis TextField
        TextField Celsuis_Value = new TextField();
        Celsuis_Value.setPromptText("Celsius");

        // Fahrenheit TextField
        TextField Fahrenheit_Value = new TextField();
        Fahrenheit_Value.setPromptText("Fahrenheit");

        // Enter Actions
        Celsuis_Value.setOnKeyPressed(new EventHandler<KeyEvent>() {

            @Override
            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode() == KeyCode.ENTER) {
                    Fahrenheit_Value.setText(Double.toString(celsiusToFahrenheit(Double.parseDouble(Celsuis_Value.getText()))));
                }
            }
        });
        Fahrenheit_Value.setOnKeyPressed(new EventHandler<KeyEvent>() {

            @Override
            public void handle(KeyEvent keyEvent) {
                if (keyEvent.getCode() == KeyCode.ENTER) {
                    Celsuis_Value.setText(Double.toString(fahrenheitToCelsius(Double.parseDouble(Fahrenheit_Value.getText()))));
                }
            }
        });

        // GridPanel Section & Adding Everything to Gridline
        GridPane root = new GridPane();
        root.getChildren().addAll(Celsius_Text, Fahrenheit_Text, Celsuis_Value, Fahrenheit_Value);

        // Set Padding for Cells
        root.setPadding(new Insets(50, 50, 50, 50));

        // Position of Elements/Nodes
        GridPane.setConstraints(Celsius_Text, 0, 0);
        GridPane.setConstraints(Fahrenheit_Text, 0, 1);
        GridPane.setConstraints(Celsuis_Value, 1, 0);
        GridPane.setConstraints(Fahrenheit_Value, 1, 1);

        // Scene init & Dimensions
        Scene scene = new Scene(root, 300, 250);

        // Stage Title
        primaryStage.setTitle("Celsius and Fahrenheit Conversion");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    public static double celsiusToFahrenheit(double celsius) {
        return ((celsius * 9/5) + 32 );
    }

    public static double fahrenheitToCelsius(double fahrenheit) {
        return ((fahrenheit - 32) * 5) / 9;

    }

}
