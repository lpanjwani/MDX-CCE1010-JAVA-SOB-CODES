/*
 - Student first name: String
 – Student surname: String
 – Student gender: char
 – Student age: int
 – Home student: Boolean
 */
package week_11_task;

/**
 *
 * @author M00692913
 */
public class Student {

    String F_Name;
    String Surname;
    char Gender;
    int age;
    Boolean Home_Student;

    public Student(String a, String b, char c, int d, Boolean e) {
        this.F_Name = a;
        this.Surname = b;
        this.Gender = c;
        this.age = d;
        this.Home_Student = e;

    }

    public String[] Retrieve() {
        String[] response = new String[5];
        
        response[0] = this.F_Name;
        response[1] = this.Surname;
        response[2] = String.valueOf(this.Gender);
        response[3] = String.valueOf(this.age);
        response[4] = String.valueOf(this.Home_Student);
        
        return response;
    }

}
