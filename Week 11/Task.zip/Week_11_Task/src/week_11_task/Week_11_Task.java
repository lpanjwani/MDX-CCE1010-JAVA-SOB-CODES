/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package week_11_task;

import java.util.Scanner;

/**
 *
 * @author M00692913
 */
public class Week_11_Task {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        Student[] studentArray = new Student[10];

        int length = 1;

        for (int i = 0; i < length; i++) {
            System.out.printf("Enter First Name for Student %d: \n", (i + 1));
            String a = input.next();
            System.out.printf("Enter Last Name for Student %d: \n", (i + 1));
            String b = input.next();
            System.out.printf("Enter Gender for Student %d: \n", (i + 1));
            char c = input.next().charAt(0);
            System.out.printf("Enter Age for Student %d: \n", (i + 1));
            int d = input.nextInt();
            System.out.printf("Enter Home Student or Not for Student %d: \n", (i + 1));
            boolean e = input.nextBoolean();
            studentArray[i] = new Student(a, b, c, d, e);
        }
        for (int j = 0; j < length; j++) {

            String[] response = studentArray[j].Retrieve();

            System.out.printf("First Name for Student %d: %s \n", (j + 1), response[0]);
            System.out.printf("Last Name for Student %d: %s \n", (j + 1), response[1]);
            System.out.printf("Gender for Student %d: %c \n", (j + 1), response[2].charAt(0));
            System.out.printf("Age for Student %d: %d \n", (j + 1), Integer.valueOf(response[3]));
            System.out.printf("Is Student %d Home Student: %b \n", (j + 1), Boolean.valueOf(response[4]));
        }
    }

}
