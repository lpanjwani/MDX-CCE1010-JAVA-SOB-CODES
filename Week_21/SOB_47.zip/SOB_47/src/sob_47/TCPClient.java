package sob_47;

import java.io.*;
import java.net.*;
import java.util.Scanner;

/**
 *
 * @author Matthew
 */
class TCPClient {

    public static void main(String[] args) throws UnknownHostException,
            IOException, ClassNotFoundException {
        Socket socket = new Socket("localhost", 4444);
        ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
        Scanner in = new Scanner(System.in);

        System.out.println("Enter Interest Rate: ");
        int interestRate = in.nextInt();
        System.out.println("Enter Number of Years: ");
        int numYears = in.nextInt();
        System.out.println("Enter Amount: ");
        int amount = in.nextInt();

        Loan loan = new Loan(interestRate, numYears, amount);
        output.writeObject(loan);

        ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
        Loan returnMessage = (Loan) input.readObject();
        System.out.println(returnMessage.getPaymentDetails());
        socket.close();
    }
}
