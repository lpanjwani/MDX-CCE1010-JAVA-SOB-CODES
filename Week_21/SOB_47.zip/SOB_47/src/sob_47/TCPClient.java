package sob_47;

import java.io.*;
import java.net.*;

/**
 *
 * @author Matthew
 */
class TCPClient {

    public static void main(String[] args) throws UnknownHostException,
            IOException, ClassNotFoundException {
        Socket socket = new Socket("localhost", 4444);
        ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
        Loan loan = new Loan(10, 2, 5000);
        output.writeObject(loan);

        ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
        Loan returnMessage = (Loan) input.readObject();
        System.out.println(returnMessage.getPaymentDetails());
        socket.close();
    }
}
