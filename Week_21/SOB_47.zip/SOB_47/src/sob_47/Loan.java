/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_47;

import java.io.Serializable;

/**
 *
 * @author Matthew
 */
public class Loan implements Serializable {

    private int interestRate;
    private int numYears;
    private int amount;
    private int monthlyPayment;
    private int totalPayment;

    Loan(int interestRate, int numYears, int amount) {
        this.interestRate = interestRate;
        this.numYears = numYears;
        this.amount = amount;
    }

    public void calculatePayment() {
        this.totalPayment = this.amount + (this.interestRate * this.amount);
        this.monthlyPayment = this.totalPayment / (this.numYears * 2);

    }

    public int getTotalPayment() {
        return this.totalPayment;
    }

    public int getMonthlyPayment() {
        return this.monthlyPayment;
    }

    public String getPaymentDetails() {
        return "Monthly Payment is: " + this.monthlyPayment + "\n Total Payment is: " + this.totalPayment;
    }
}
