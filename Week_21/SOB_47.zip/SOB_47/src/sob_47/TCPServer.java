package sob_47;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author Lavesh
 */
public class TCPServer {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ServerSocket ss = new ServerSocket(4444);
        Socket socket = ss.accept();

        ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
        ObjectInputStream input = new ObjectInputStream(socket.getInputStream());

        Loan message = (Loan) input.readObject();
        message.calculatePayment();

        output.writeObject(message);
        socket.close();
    }
}
