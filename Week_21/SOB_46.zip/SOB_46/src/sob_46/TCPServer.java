package sob_46;

import java.io.*;
import java.net.*;

/**
 *
 * @author Matthew
 */
class TCPClient extends Thread{

   private ServerSocket serverSocket;
   
   public TCPClient(int port) throws IOException {
      serverSocket = new ServerSocket(port);
      serverSocket.setSoTimeout(10000);
   }

   public void run() {
      while(true) {
         try {
            Socket server = serverSocket.accept();
            
            DataInputStream in = new DataInputStream(server.getInputStream());
            
            String clientInput = in.readUTF();
            String[] array = clientInput.split(" ");
            
            int totalAmount = Integer.parseInt(array[2]) + (Integer.parseInt(array[0]) * Integer.parseInt(array[2]));
            int monthlyPayment = totalAmount / (Integer.parseInt(array[1]) * 2);
            
            DataOutputStream out = new DataOutputStream(server.getOutputStream());
            out.writeUTF( "Total Payment: " + totalAmount + "\n" + "Montly Payment: " + monthlyPayment);
            server.close();
            
         } catch (SocketTimeoutException s) {
            break;
         } catch (IOException e) {
            e.printStackTrace();
            break;
         }
      }
   }
   
   public static void main(String [] args) {
      int port = 6000;
      try {
         Thread t = new TCPClient(port);
         t.start();
      } catch (IOException e) {
         e.printStackTrace();
      }
   }
}