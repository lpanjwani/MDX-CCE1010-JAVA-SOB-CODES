package sob_46;

import java.io.*;
import java.net.*;

/**
 *
 * @author Matthew
 */
class TCPServer {

    public static void main(String[] args) {
        while (true) {
            try {
                ServerSocket serverSocket = new ServerSocket(6000);
                Socket server = serverSocket.accept();

                DataInputStream in = new DataInputStream(server.getInputStream());

                String clientInput = in.readUTF();
                String[] array = clientInput.split(" ");

                int totalAmount = Integer.parseInt(array[2]) + (Integer.parseInt(array[0]) * Integer.parseInt(array[2]));
                int monthlyPayment = totalAmount / (Integer.parseInt(array[1]) * 2);

                DataOutputStream out = new DataOutputStream(server.getOutputStream());
                out.writeUTF("Total Payment: " + totalAmount + "\n" + "Montly Payment: " + monthlyPayment);
                server.close();

            } catch (SocketTimeoutException s) {
                break;
            } catch (IOException e) {
                e.printStackTrace();
                break;
            }
        }
    }

}
