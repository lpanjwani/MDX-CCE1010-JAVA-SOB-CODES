package SOB_46;

import java.io.*;
import java.net.*;

/**
 *
 * @author Lavesh
 */
class TCPServer {

    public static void main(String[] args) {
        String serverName = "localhost";
        int port = 6000;
        
        int interestRate = 10;
        int numYears = 2;
        int amount = 5000;
        
        try {
            Socket client = new Socket(serverName, port);
            
            OutputStream outToServer = client.getOutputStream();
            DataOutputStream out = new DataOutputStream(outToServer);
            
            out.writeUTF(interestRate + " " + numYears + " " + amount);
            InputStream inFromServer = client.getInputStream();
            DataInputStream in = new DataInputStream(inFromServer);

            System.out.println(in.readUTF());
            client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
