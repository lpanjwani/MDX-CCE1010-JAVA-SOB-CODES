package SOB_46;

import java.io.*;
import java.net.*;
import java.util.Scanner;

/**
 *
 * @author Lavesh
 */

class TCPClient {

    public static void main(String[] args) {
        String serverName = "localhost";
        int port = 6000;
        
        Scanner input = new Scanner(System.in);
        
        
        try {
            Socket client = new Socket(serverName, port);
            
            OutputStream outToServer = client.getOutputStream();
            DataOutputStream out = new DataOutputStream(outToServer);
            
            System.out.println("Enter Interest Rate: ");
            int interestRate = input.nextInt();
            System.out.println("Enter Number of Years: ");
            int numYears = input.nextInt();
            System.out.println("Enter Amount: ");
            int amount = input.nextInt();
            
            out.writeUTF(interestRate + " " + numYears + " " + amount);
            
            InputStream inFromServer = client.getInputStream();
            DataInputStream in = new DataInputStream(inFromServer);

            System.out.println(in.readUTF());
            client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
