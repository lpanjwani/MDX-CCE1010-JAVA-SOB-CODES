package sob_48;

import java.io.*;
import java.net.*;

/**
 *
 * @author Lavesh
 */
class TCPClient {

    public static void main(String[] args) {
        int port = 4000;
        try {
            Socket client = new Socket("localhost", port);
            
            OutputStream outToServer = client.getOutputStream();
            DataOutputStream out = new DataOutputStream(outToServer);
            
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.printf("Enter Message: ");
            out.writeUTF(reader.readLine());
            InputStream inFromServer = client.getInputStream();
            DataInputStream in = new DataInputStream(inFromServer);

            System.out.println("Server says " + in.readUTF());
            client.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
