/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob48;

import java.awt.event.KeyEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author M00695544
 */
public class Server extends Application {


    TextArea t1 = new TextArea();
    ServerSocket welcomeSocket;
    Socket connectionSocket;

    @Override
    public void start(Stage primaryStage) throws Exception {
        Label l2 = new Label("To  : ");
        TextArea t2 = new TextArea();
        t1.setEditable(false);
        Button btn = new Button();
        btn.setText("Send");
        GridPane root = new GridPane();
        
        GridPane.setConstraints(t1, 0, 2);
        GridPane.setConstraints(l2, 0, 3);
        GridPane.setConstraints(t2, 0, 4);
        GridPane.setConstraints(btn, 0, 5);

        root.getChildren().addAll(t1, l2, t2, btn);

        Scene scene = new Scene(root, 500, 500);

        primaryStage.setTitle("Server");
        primaryStage.setScene(scene);
        primaryStage.show();
        welcomeSocket = new ServerSocket(3034);

        connectionSocket = welcomeSocket.accept();

        btn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {

                try {

                    DataOutputStream out = new DataOutputStream(connectionSocket.getOutputStream());

                    out.writeUTF(t2.getText());
                    t2.clear();

                } catch (Exception e) {

                }

            }

        });
        ChildThread thread = new ChildThread();
        thread.start();
    }

    class ChildThread extends Thread {

        @Override
        public void run() {
            try {

                DataInputStream in = new DataInputStream(connectionSocket.getInputStream());

                while (true) {
                    t1.appendText(t1.getText() + "\n" + in.readUTF());
                }
            } catch (Exception e) {

            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

}
