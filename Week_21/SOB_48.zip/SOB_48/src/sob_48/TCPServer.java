package sob_48;

import java.io.*;
import java.net.*;

/**
 *
 * @author Lavesh
 */
class TCPServer {

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(4000);
            Socket server = serverSocket.accept();

            DataInputStream in = new DataInputStream(server.getInputStream());

            System.out.println("User says: " + in.readUTF());
            DataOutputStream out = new DataOutputStream(server.getOutputStream());

            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.printf("Enter Message: ");
            out.writeUTF(reader.readLine());

            out.writeUTF("Thank you for connecting to " + server.getLocalSocketAddress()
                    + "\nGoodbye!");
            server.close();

        } catch (SocketTimeoutException s) {
            System.out.println("Socket timed out!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
