/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_48;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Lavesh
 */
public class Client extends Application {

    Socket clientSocket;
    DataInputStream in;
    TextArea t1 = new TextArea();

    @Override
    public void start(Stage primaryStage) throws Exception {

        Label l2 = new Label("To  : ");
        TextArea t2 = new TextArea();
        t1.setEditable(false);
        Button btn = new Button();
        btn.setText("Send");
        GridPane root = new GridPane();
        GridPane.setConstraints(t1, 0, 2);
        GridPane.setConstraints(l2, 0, 3);
        GridPane.setConstraints(t2, 0, 4);
        GridPane.setConstraints(btn, 0, 10);

        root.getChildren().addAll(t1, l2, t2, btn);

        Scene scene = new Scene(root, 500, 500);

        primaryStage.setTitle("Client");
        primaryStage.setScene(scene);
        primaryStage.show();

        clientSocket = new Socket("localhost", 3034);

        btn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {

                try {

                    DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());

                    out.writeUTF(t2.getText());
                    t1.appendText("Me : " + t2.getText() + "\n");
                    t2.clear();

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

        });
        ChildThread thread = new ChildThread();
        thread.start();
    }

    class ChildThread extends Thread {

        @Override
        public void run() {
            try {

                in = new DataInputStream(clientSocket.getInputStream());
                while (true) {

                    t1.appendText(t1.getText() + "\n" + in.readUTF());
                }
            } catch (Exception e) {

            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

}
