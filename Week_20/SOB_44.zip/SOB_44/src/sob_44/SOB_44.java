/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_44;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 *
 * @author Lavesh
 */
public class SOB_44 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        File countFile = new File("text.txt");

        try {
            Scanner wordInput = new Scanner(countFile);
            Scanner lineInput = new Scanner(countFile);
            int lineCount = 0;
            int wordCount = 0;
            int charLength = 0;
            while (wordInput.hasNext()) {
                wordCount++;
                String temp = wordInput.next();
                charLength += temp.length();
            }
            while (lineInput.hasNextLine()) {
                lineCount++;
                System.out.println(lineInput.nextLine());
            }
            System.out.println("Character Count: " + charLength);
            System.out.println("Word Count: " + wordCount);
            System.out.println("Line Count: " + lineCount);
                       
        } catch (FileNotFoundException ex) {
            System.out.println("File Not Found!");
        }

    }

}
