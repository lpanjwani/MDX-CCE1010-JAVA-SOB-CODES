package sob45;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SOB45 {

    public static void main(String[] args) throws ClassNotFoundException, IOException 
    {
        try 
        {
            ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("student.dat"));
            Student std_1 = new Student();
            output.writeObject(std_1);
            
            ObjectInputStream input = new ObjectInputStream(new FileInputStream("student.dat"));
            Student std_2 = (Student) input.readObject();
            System.out.println(std_1.getStudentName());
            System.out.print(" " + std_1.getStudentSurname());
            System.out.println(std_1.getStudentNumber());
        } 
        
        catch (IOException Ex) 
        {
            System.out.println("Error");
        }
    }
}
