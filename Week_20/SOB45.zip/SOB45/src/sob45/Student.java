package sob45;

import java.io.Serializable;

public class Student implements Serializable{
    private String studentName;
    private String studentSurname;
    private String studentNumber;
    
    public Student() {
        this.studentName = "Lavesh";
        this.studentSurname = "Panjwani";
        this.studentSurname = "M00692913";
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String stdname) {
        this.studentName = stdname;
    }

    public String getStudentSurname() {
        return studentSurname;
    }

    public void setStudentSurname(String stdsurname) {
        this.studentSurname = stdsurname;
    }

    public String getStudentNumber() {
        return studentNumber;
    }

    public void setStudentNumber(String stdnumber) {
        this.studentNumber = stdnumber;
    }
}
