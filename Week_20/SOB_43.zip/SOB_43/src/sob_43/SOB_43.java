package sob_43;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;
/**
 *
 * @author Lavesh
 */
public class SOB_43 {
    
    public static void main(String[] args) throws FileNotFoundException {
        File numbersFile = new File("numbers.txt");
        if(!numbersFile.exists()){
            PrintWriter output = new PrintWriter(numbersFile);
            for(int i=0;i<120;i++){
                output.printf("%d ", (int)(1 + Math.random() * 120));
            }
            output.close();
        }
        Scanner input = new Scanner(numbersFile);
        int[] Values = new int[120];
        int j = 0;
        while(input.hasNext()){
            Values[j] = input.nextInt();
            j++;
        }
        Arrays.sort(Values);
        for(int z=0;z<Values.length;z++){
            System.out.println(Values[z]);
        }
    }
}
