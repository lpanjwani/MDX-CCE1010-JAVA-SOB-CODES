/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_39;

import java.util.Scanner;

/**
 *
 * @author lpanj
 */
public class SOB_39 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        boolean flag = false;
        do {
            try {
                System.out.println("Enter Binary Number: ");
                String in = input.next();

                int output = bin2Dec(in);
                System.out.printf("Decimal Number is: %d \n", output);

                flag = true;
            } catch (NumberFormatException ex) {
                System.out.println("Please Enter Binary Numbers only!");
            }
        } while (flag == false);

    }

    public static int bin2Dec(String in) throws NumberFormatException {
        int output = 0;

        for (int power = 0, position = in.length() - 1; power < in.length(); power++, position--) {
            if (Integer.parseInt(Character.toString(in.charAt(position))) == 0 || 1 == Integer.parseInt(Character.toString(in.charAt(position)))) {
                output = (int) (output + (Math.pow(2, power) * Integer.parseInt(Character.toString(in.charAt(position)))));
            } else {
                throw new NumberFormatException();
            }
        }
        return output;
    }

}
