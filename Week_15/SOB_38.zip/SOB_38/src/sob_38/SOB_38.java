/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_38;

import java.util.Scanner;

/**
 *
 * @author lpanj
 */
public class SOB_38 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int[] db = new int[120];

        for (int i = 0; i < 120; i++) {
            db[i] = (int) (1 + Math.random() * 120);
        }
        boolean flag = false;

        do {
            try {
                System.out.println("Enter index to be viewed: ");
                int index = input.nextInt();
                System.out.printf("Value at Array Index %d is %d \n", index, db[index]);
                flag = true;
            } catch (ArrayIndexOutOfBoundsException ex) {
                System.out.println("Please enter range between 1-120!");
            }
        } while (flag == false);

    }

}
