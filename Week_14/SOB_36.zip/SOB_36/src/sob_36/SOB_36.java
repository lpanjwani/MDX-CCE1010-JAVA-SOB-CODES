/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_36;

import java.util.Scanner;

/**
 *
 * @author lpanj
 */
public class SOB_36 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Enter Side 1: ");
        int side1 = input.nextInt();

        System.out.println("Enter Side 2: ");
        int side2 = input.nextInt();

        System.out.println("Enter Side 3: ");
        int side3 = input.nextInt();

        System.out.println("Enter Colour: ");
        String color = input.next();

        System.out.println("Triangle Filled? Enter True or False only: ");
        boolean filled = input.hasNextBoolean();

        Triangle main = new Triangle(side1, side2, side3, color, filled);

        System.out.println("Area is " + main.getArea());
        System.out.println("Parameter is " + main.getPerimeter());
        System.out.println("Colour is " + main.RetieveColor());
        System.out.println("Filled is " + main.Retievefilled());

    }

}
