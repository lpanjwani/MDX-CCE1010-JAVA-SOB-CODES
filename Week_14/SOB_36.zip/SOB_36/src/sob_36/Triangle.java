/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_36;

/**
 *
 * @author lpanj
 */
public class Triangle extends GeometricObject {

    public double side1 = 1.0;
    public double side2 = 1.0;
    public double side3 = 1.0;
    public String color;
    public boolean filled;

    public Triangle() {
        this.side1 = 1.0;
        this.side2 = 1.0;
        this.side3 = 1.0;
        this.color = "Red";
        this.filled = false;
    }

    public Triangle(double side1, double side2, double side3, String color, boolean filled) {
        this.side1 = side1;
        this.side2 = side2;
        this.side3 = side3;
        this.color = color;
        this.filled = filled;
    }

    public double[] Retieve() {
        double response[] = new double[3];
        response[0] = this.side1;
        response[1] = this.side2;
        response[2] = this.side3;
        return response;
    }

    public String RetieveColor() {
        return this.color;
    }

    public boolean Retievefilled() {
        return this.filled;
    }

    public double getArea() {
        double response = (this.side1 * this.side3) / 2;
        return response;
    }

    public double getPerimeter() {
        double response = this.side1 + this.side2 + this.side3;
        return response;
    }

    public String toString() {
        return "Triangle: side1 = " + this.side1 + " side2 = " + this.side2 + " side3 = " + this.side3;
    }

}
