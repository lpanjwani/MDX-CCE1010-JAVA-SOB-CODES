/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_33;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author M00692913
 */
public class SOB_33 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        ArrayList<Integer> list = new ArrayList<>();

        for (int index = 0; index < 5; index++) {
            System.out.printf("Enter %d Value: ", (index + 1));
            int temp = input.nextInt();
            list.add(temp);
        }

        sort(list);
    }

    public static void sort(ArrayList<Integer> list) {
        for (int count_1 = 0; count_1 < list.size(); count_1++) {
            for (int count_2 = 1; count_2 < list.size(); count_2++) {
                if (list.get(count_2) > list.get(count_2-1)) {
                    int temp_2 = list.get(count_2);
                    list.set(count_2, list.get(count_2-1));
                    list.set(count_2-1, temp_2);
                }
            }
        }
            System.out.print(list);
    }
}
