package sob_34;

import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lpanj
 */
public class Faculty extends Employee {

    private String officeHours;
    private String rank;

    public String getOfficeHours() {
        return officeHours;
    }

    public void setOfficeHours(String officeHours) {
        this.officeHours = officeHours;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public Faculty(String name, String address, double phone, String email,
            String office, int salary, String officeHours, String rank, Date date) {

        super(name, address, phone, email, office, salary, date);
        this.officeHours = officeHours;
        this.rank = rank;

    }

}
