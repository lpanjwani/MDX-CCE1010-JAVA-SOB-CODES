/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_34;

import java.util.Date;
import java.util.ArrayList;

/**
 *
 * @author lpanj
 */
public class SOB_34 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Polymorphism
        Person person = new Person("Lavesh", "Dubai",
                0562170241, "lpanjwani@outlook.com");

        Person student = new Student("Lavesh", "Dubai", 0562170241,
                "lpanjwani@outlook.com", "FRESHMAN");

        Person employee = new Employee("Lavesh", "Dubai", 0562170241,
                "lpanjwani@outlook.com", "B-104", 2500, new Date());

        Person faculty = new Faculty("Lavesh", "Dubai", 0562170241,
                "lpanjwani@outlook.com", "B-104", 2500, "9PM TO 5PM", "Senior Professor", new Date());

        Person staff = new Staff("Lavesh", "Dubai", 0562170241,
                "lpanjwani@outlook.com", "1", 2500, 456123, new Date());

        // Input into ArrayList 
        ArrayList<Person> p = new ArrayList<>();
        p.add(person);
        p.add(student);
        p.add(employee);
        p.add(faculty);
        p.add(staff);
        
        for (Person p1 : p) {
            System.out.println(p1.toString());
            String classname = p1.getClass().getSimpleName();
            if (classname.equals("Student")) {
                Student s = (Student) p1;
                System.out.println("Student Status is " + s.getStatus());
            }

        }

    }

}
