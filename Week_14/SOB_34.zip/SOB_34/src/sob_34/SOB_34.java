/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_34;

import java.util.Date;

/**
 *
 * @author lpanj
 */
public class SOB_34 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Person person = new Person("Lavesh", "Dubai",
                0562170241, "lpanjwani@outlook.com");

        Student student = new Student("Lavesh", "Dubai", 0562170241,
                "lpanjwani@outlook.com", "FRESHMAN");

        Employee employee = new Employee("Lavesh", "Dubai", 0562170241,
                "lpanjwani@outlook.com", "B-104", 2500, new Date());

        Faculty faculty = new Faculty("Lavesh", "Dubai", 0562170241,
                "lpanjwani@outlook.com", "B-104", 2500, "9PM TO 5PM", "Senior Professor", new Date());

        Staff staff = new Staff("Lavesh", "Dubai", 0562170241,
                "lpanjwani@outlook.com", "1", 2500, 456123, new Date());

    }

}
