/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_34;

/**
 *
 * @author lpanj
 */
public class Person {

    public String name;
    public String address;
    public double phone;
    public String email;

    public Person() {
        this.name = "Default";
        this.address = "Dubai";
        this.phone = 501234;
        this.email = "email@domain.com";
    }

    public Person(String name, String address, double phone, String email) {
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getPhone() {
        return phone;
    }

    public void setPhone(double phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void Print() {
        System.out.println(this.name);
        System.out.println(this.address);
        System.out.println(this.phone);
        System.out.println(this.email);
    }
}
