/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_34;

import java.util.Date;
/**
 *
 * @author lpanj
 */
public class Staff extends Employee {

    private double staffid;
    
    public Staff(String name, String address, double phone,
            String email, String office, int salary, double staffid, Date date) {

        super(name, address, phone, email, office, salary, date);

    }

}
