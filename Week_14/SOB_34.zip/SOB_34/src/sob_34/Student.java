/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_34;

/**
 *
 * @author lpanj
 */
public class Student extends Person {

    public static String status;

    public Student(String name, String address, double phone, String email, final String status) {
        super(name, address, phone, email);
        this.status = status;
    }

    public Student() {
        super("Default", "Dubai", 501234, "email@domain.com");
        this.status = "Fresher";
    }

    public void Print() {
        super.Print();
        System.out.println(this.status);
    }
    
}
