/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_34;

import java.util.Date;

/**
 *
 * @author lpanj
 */
public class Employee extends Person {

    public String office;
    public int salary;
    public Date date;

    public Employee(String name, String address, double phone, String email, String office, int salary, Date date) {
        super(name, address, phone, email);
        this.office = office;
        this.salary = salary;
        this.date = date;
    }

    public Employee() {
        super("Default", "Dubai", 501234, "email@domain.com");
        this.office = "16-403";
        this.salary = 2500;
        this.date = new Date();
    }

    public void Print() {
        super.Print();
        System.out.println(this.office);
        System.out.println(this.salary);
        System.out.println(this.date);

    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getOffice() {
        return office;
    }

    public void setOffice(String office) {
        this.office = office;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Name: " + this.name + " Address: " + this.address + " Phone: " + this.phone + " Email: " + this.email + " Office: " + this.office + " Salary: " + this.salary + " Date: " + this.date;
    }

}
