/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_35;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author lpanj
 */
public class SOB_35 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        ArrayList<Integer> list = new ArrayList<Integer>();

        System.out.println("Enter 0 to end input!");

        for (int i = 0;; i++) {
            System.out.println("Enter Value: ");
            int temp = input.nextInt();

            if (temp == 0) {
                break;
            }

            list.add(temp);
        }
        int reply = min(list);
        System.out.println("Lowest Value is " + reply);
    }

    public static Integer min(ArrayList<Integer> list) {
        int lowest = list.get(0);
        for (int j = 0; j < list.size(); j++) {
            if (lowest > list.get(j)) {
                lowest = list.get(j);
            }
        }
        return lowest;
    }
}
