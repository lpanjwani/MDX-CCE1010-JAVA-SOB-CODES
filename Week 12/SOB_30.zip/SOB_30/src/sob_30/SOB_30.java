/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_30;

/**
 *
 * @author Student
 */
public class SOB_30 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MyInteger Value = new MyInteger(3);

        System.out.printf("Value is %d \n", Value.Retrieve());

        System.out.printf("Value %d is Even: %b \n", 3, Value.isEven());
        System.out.printf("Value %d is Odd: %b \n", 3, Value.isOdd());
        System.out.printf("Value %d is Prime: %b \n", 3, Value.isPrime());

        System.out.printf("Value %d is Even: %b \n", 4, Value.isEven(4));
        System.out.printf("Value %d is Odd: %b \n", 4, Value.isOdd(4));
        System.out.printf("Value %d is Prime: %b \n", 4, Value.isPrime(4));

        System.out.printf("Value %d is Equal to %d: %b \n", 4, Value.Retrieve(), Value.equals(4));
        
        char[] array_1 = new char[]{'a','b'};
        System.out.printf("Value of CHAR Array is %d \n", Value.parseInt(array_1));
        
        String[] array_2 = new String[]{"Hello","World"};
        System.out.printf("Value of STRING Array is %d \n", Value.parseInt(array_2));
    }

}
