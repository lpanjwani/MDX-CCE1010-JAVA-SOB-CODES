/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_32;

/*
 * @author M00692913
 */
public class MyString1 {

    char[] chars;

    public MyString1(char[] chars) {
        this.chars = chars;
    }

    public char charAt(int index) {
        char required_char = this.chars[index];
        return required_char;
    }

    public int length() {
        int length = this.chars.length;
        return length;
    }

    public MyString1 substring(int begin, int end) {
        String chars_temp = this.chars.toString();
        chars_temp.substring(begin, end);
        char[] chars = chars_temp.toCharArray();
        
        return new MyString1(chars);
    }

    public MyString1 toLowerCase() {
        String chars_temp = this.chars.toString();
        chars_temp.toLowerCase();
        char[] chars = chars_temp.toCharArray();
        
        return new MyString1(chars);
    }

    public boolean equals(MyString1 s) {
        String chars_temp = this.chars.toString();
        boolean equals = chars_temp.equals(s);
        return equals;
    }

    public static MyString1 valueOf(int i) {
        String chars_temp = this.chars.toString();
        String chars_temp2 = chars_temp.valueOf(i);
        char[] chars = chars_temp2.toCharArray();
        
        return new MyString1(chars);
    }

}
