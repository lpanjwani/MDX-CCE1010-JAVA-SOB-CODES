/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_31;

/**
 *
 * @author lpanj
 */
public class SOB_31 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
		MyDate date_1 = new MyDate();
		MyDate date_2 = new MyDate(43455555133101L);

		System.out.println("Date 1: " + date_1.getDay() + "/" + (date_1.getMonth()-1) +
			"/" + date_1.getYear());
		System.out.println("Date 2: " + date_2.getDay() + "/" + (date_2.getMonth()-1) +
			"/" + date_2.getYear());
    }
    
}
