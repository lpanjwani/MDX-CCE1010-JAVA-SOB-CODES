package sob_31;

import java.util.GregorianCalendar;

public class MyDate {
	private int year;
	private int month;
	private int date;

	public MyDate() {
		GregorianCalendar calander = new GregorianCalendar();
		this.year = calander.get(GregorianCalendar.YEAR);
		this.month = calander.get(GregorianCalendar.MONTH);
		this.date = calander.get(GregorianCalendar.DAY_OF_MONTH);
	}
        
        public MyDate(long elapsedTime) {
		GregorianCalendar calander = new GregorianCalendar();
		calander.setTimeInMillis(elapsedTime);
		this.year = calander.get(GregorianCalendar.YEAR);
		this.month = calander.get(GregorianCalendar.MONTH);
		this.date = calander.get(GregorianCalendar.DAY_OF_MONTH);
	} 

	public MyDate(int year, int month, int day) {
		this.year = year;
		this.month = month;
		this.date = day;
	}

	public int getYear() {
		return year;
	}

	public int getMonth() {
		int month_new = this.month + 1;
		return month_new;
	}

	public int getDay() {
		return this.date;
	}
        
	public void setDate(long elapsedTime) {
		GregorianCalendar calander = new GregorianCalendar();
		calander.setTimeInMillis(elapsedTime);
		this.year = calander.get(GregorianCalendar.YEAR);
		this.month = calander.get(GregorianCalendar.MONTH);
		this.date = calander.get(GregorianCalendar.DAY_OF_MONTH);
	} 
}