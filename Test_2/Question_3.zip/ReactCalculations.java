public class ReactCalculations {
 public static double rectarea(double l,double b) {
        return l*b;
    }

    public static double rectpermeter(double l, double b) {
      double value = (2*l)+(2*b);
        return value;

    }

    public static double rectdiagnol(double length, double width) {
        double value = Math.sqrt((Math.pow(length,2)+ Math.pow(width, 2)));
        return value;
    }   
}