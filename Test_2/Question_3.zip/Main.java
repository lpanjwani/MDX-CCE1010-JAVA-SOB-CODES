import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Scanner Declearation
        Scanner in = new Scanner(System.in);

        // Get Number of Entries from User
        System.out.println("Enter Number of Entries: ");
        int n = in.nextInt();

        // Decleare Array
        double[] height = new double[n];
        double[] length = new double[n];
        
        // Decleare 2D Array
        double[][] response= new double[n][3];
        
        // init ReactCalculations class
        ReactCalculations Calculations = new ReactCalculations();
        
        // Get Inputs from User
        for(int i=0;i<n;i++){
            // Ask User for Height
          System.out.println("Enter " + (i+1) + " Height: ");
          height[i] =  in.nextDouble();
            // Ask User for Length
          System.out.println("Enter " + (i+1) + " Length: ");
          length[i] =  in.nextDouble();
            // Call Methods for Calculation
          response[i][0] = Calculations.rectarea(length[i],height[i]);
          response[i][1] = Calculations.rectpermeter(length[i],height[i]);
          response[i][2] = Calculations.rectdiagnol(length[i],height[i]);
            // Diplay Results to User
          System.out.printf("Area \t \t %f \n", response[i][0]);
          System.out.printf("Perimeter \t %f \n", response[i][1]);
          System.out.printf("Diagonal \t %f \n", response[i][2]);
        }

    }

}
