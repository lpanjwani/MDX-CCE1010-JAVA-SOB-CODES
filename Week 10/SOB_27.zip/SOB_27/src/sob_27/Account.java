/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_27;

/**
 *
 * @author M00692913
 */
public class Account {

    private int id = 0;
    private double balance = 0;
    private double annualInterestRate = 0;
    private String dateCreated;

    public void Account() {
        this.id = 0;
        this.balance = 0;
        this.annualInterestRate = 0;
        this.dateCreated = "05/12/2018";
    }

    public void Account(int id, double balance) {
        this.id = id;
        this.balance = balance;
        this.annualInterestRate = 0;
        this.dateCreated = "05/12/2018";
    }

    public Double[] GetFirst3Values() {

        Double response[] = new Double[3];

        response[0] = (double) (this.id);
        response[1] = this.balance;
        response[2] = this.annualInterestRate;

        return response;
    }

    public void SetFirst3Values(int id, double balance, double annualInterestRate) {

        this.id = id;
        this.balance = balance;
        this.annualInterestRate = annualInterestRate;

    }

    public String AccessDateCreated() {

        String response = this.dateCreated;

        return response;
    }

    public Double getMonthlyInterestRate() {
        Double response = this.annualInterestRate / 12;

        return response;
    }

    public Double getMonthlyInterest() {
        Double response = (this.annualInterestRate / 12 / 100) * this.balance;

        return response;
    }

    public void withdraw(double withdrawl_amount) {
        this.balance = this.balance - withdrawl_amount;
    }

    public void deposit(double deposit_amount) {
        this.balance = this.balance + deposit_amount;
    }
}
