/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_27;

/**
 *
 * @author M00692913
 */
public class SOB_27 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Account account_1 = new Account();

        account_1.Account();

        account_1.SetFirst3Values(1122, 20000, 4.5);

        account_1.withdraw(2500);

        account_1.deposit(3000);

        Double[] Response_DoubleValues = account_1.GetFirst3Values();

        int Response_Balance = Response_DoubleValues[1].intValue();
        Double Response_MonthlyInterest = account_1.getMonthlyInterest();
        String Response_DateCreated = account_1.AccessDateCreated();

        System.out.printf("Account Balance is $%d\nMonthly Interest is $%f\nDate Created is %s", Response_Balance,Response_MonthlyInterest,Response_DateCreated);

    }

}
