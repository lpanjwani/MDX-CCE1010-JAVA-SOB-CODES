/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_30;

/**
 *
 * @author Student
 */
public class MyInteger {

    int value;

    MyInteger(int value) {
        this.value = value;
    }

    public int Retrieve() {
        return this.value;
    }

    public boolean isEven() {
        if (this.value % 2 == 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isOdd() {
        if (this.value % 2 != 0) {
            return false;
        } else {
            return true;
        }
    }

    public boolean isPrime() {
        boolean flag = true;
        for (int i = 2; i <= this.value; i++) {
            if (this.value % i == 0) {
                flag = false;
            }
        }
        return flag;
    }

    public static boolean isEven(int a) {
        if (a % 2 == 0) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean isOdd(int a) {
        if (a % 2 != 0) {
            return false;
        } else {
            return true;
        }
    }

    public static boolean isPrime(int a) {
        boolean flag = true;
        for (int i = 2; i <= a; i++) {
            if (a % i == 0) {
                flag = false;
            }
        }
        return flag;
    }

    public boolean equals(int a) {
        if (a == this.value) {
            return true;
        } else {
            return false;
        }
    }

    public static int parseInt(char[] a) {

        int value = 0;

        for (int i = 0; i < a.length; i++) {
            value = value + Integer.valueOf(a[i]);
        }

        return value;
    }

    public static int parseInt(String[] a) {

        int value = 0;

        for (int i = 0; i < a.length; i++) {
            value = value + Integer.valueOf(a[i]);
        }

        return value;
    }
}
