/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_28;

/**
 *
 * @author M00692913
 */
public class SOB_28 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Fan Fan_1 = new Fan();
        Fan_1.Assign_Values(3,true,12,"Green");
        
        Fan Fan_2 = new Fan();
        Fan_2.Assign_Values(2,false,6,"Red");
        
        String response_1 = Fan_1.toString();
        String response_2 = Fan_2.toString();
        
        System.out.println("Fan 1: " + response_1);
        System.out.println("Fan 2: " + response_2);

    }

}
