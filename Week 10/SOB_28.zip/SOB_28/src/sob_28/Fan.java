/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sob_28;

/**
 *
 * @author M00692913
 */
public class Fan {

    public static final int SLOW = 1;
    public static final int MEDIUM = 2;
    public static final int FAST = 3;

    private int speed = SLOW;
    private boolean state = false;
    private double radius = 5;
    String colour = "blue";

    public void Fan() {
        this.speed = SLOW;
        this.state = false;
        this.radius = 5;
        this.colour = "blue";
    }

    public void Fan(int speed, boolean state, double radius, String colour) {
        this.speed = SLOW;
        this.state = false;
        this.radius = 5;
        this.colour = "blue";
    }

    public String[] Retrieve_Values() {

        String[] Response_To_Be_Sent = new String[4];

        Response_To_Be_Sent[0] = new Integer(this.speed).toString();
        Response_To_Be_Sent[1] = new Boolean(this.state).toString();
        Response_To_Be_Sent[2] = new Double(this.radius).toString();
        Response_To_Be_Sent[3] = this.colour;

        return Response_To_Be_Sent;
    }

    public void Assign_Values(int speed, boolean state, double radius, String colour) {

        this.speed = speed;
        this.state = state;
        this.radius = radius;
        this.colour = colour;

    }

    public String toString() {

        String Response;

        if (this.state == true) {
            Response = "Speed is " + this.speed + " Radius is " + this.radius + " Colour is " + this.colour;
        } else {
            Response = "FAN IS OFF Radius is " + this.radius + " Colour is " + this.colour;
        }

        return Response;
    }
}
